package com.soremed.backend.enums;

public enum Role {
    ADMIN,
    CLIENT,
    SERVICE_ACHAT
}
