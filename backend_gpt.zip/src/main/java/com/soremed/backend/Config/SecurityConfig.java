package com.soremed.backend.Config;

import com.soremed.backend.service.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // active CORS selon ta WebConfig
                .cors(Customizer.withDefaults())

                // désactive CSRF pour les endpoints /api/**
                .csrf(csrf -> csrf.ignoringRequestMatchers("/api/**"))

                // déclare tes règles d’accès
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/users/register").permitAll()
                        .requestMatchers("/api/medications/**")
                        .hasAnyRole("ADMIN","SERVICE_ACHAT","CLIENT")
                        .requestMatchers("/api/orders/**")
                        .hasAnyRole("ADMIN","SERVICE_ACHAT","CLIENT")
                        .anyRequest().authenticated()
                )

                // active l’authentification HTTP Basic
                .httpBasic(Customizer.withDefaults());

        return http.build();
    }

    @Bean
    @ConditionalOnMissingBean(UserDetailsService.class)
    public UserDetailsService userDetailsService(CustomUserDetailsService custom) {
        return custom;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
